<footer class="main-footer">
    <div class="footer-left">
        Copyright &copy; 2021 by Renny Suryani
    </div>
</footer>
